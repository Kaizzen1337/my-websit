import { motion } from 'framer-motion';
import { Code, Server, Smartphone } from 'lucide-react';

const About = () => {
  const skills = [
    {
      title: 'Frontend Development',
      description: 'Expertise in React, Vue, and modern CSS frameworks like Tailwind.',
      icon: <Code className="text-blue-600" size={24} />,
    },
    {
      title: 'Backend Development',
      description: 'Building scalable APIs with Node.js, Express, and PostgreSQL.',
      icon: <Server className="text-blue-600" size={24} />,
    },
    {
      title: 'Mobile Development',
      description: 'Creating cross-platform mobile apps using React Native.',
      icon: <Smartphone className="text-blue-600" size={24} />,
    },
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">About Me</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            I am a full-stack developer with over 5 years of experience in the industry.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="bg-blue-50 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                {skill.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{skill.title}</h3>
              <p className="text-gray-600">{skill.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
